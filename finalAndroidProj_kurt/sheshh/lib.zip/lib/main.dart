import 'package:flutter/material.dart';
import 'package:sheshh/pages/home_screen.dart';
import 'package:sheshh/pages/settings_screen.dart';
import 'package:sheshh/pages/logout_sample.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Home Page Example',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,  // Enable Material 3 design
      ),
      home: const HomePage(),

    );
  }
}