// home_page.dart
import 'package:flutter/material.dart';
import 'package:sheshh/pages/home_content.dart';
import 'community_page.dart';
import 'settings_screen.dart';
import 'logout_sample.dart';
import 'buttons/event_tracker_screen.dart'; // Ensure this import is correct

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 1;

  static const List<Widget> _pages = <Widget>[
    LogoutSamplePage(),
    HomeContent(), // Update to CommunityPage
    SettingsPage(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Scrollbar(
        thumbVisibility: false,
        trackVisibility: false,
        thickness: 10.0,
        radius: const Radius.circular(10.0),
        scrollbarOrientation: ScrollbarOrientation.right,
        child: Theme(
          data: Theme.of(context).copyWith(
            scrollbarTheme: ScrollbarThemeData(
              thumbColor: MaterialStateProperty.all(Colors.lightGreen),
              trackColor: MaterialStateProperty.all(Colors.lightGreen),
              radius: const Radius.circular(10.0),
            ),
          ),
          child: CustomScrollView(
            slivers: <Widget>[
              SliverAppBar(
                expandedHeight: 150.0,
                pinned: true,
                flexibleSpace: FlexibleSpaceBar(
                  title: const Text(
                    'KAMUSTA JUAN!',
                    style: TextStyle(
                      fontSize: 30,
                      fontFamily: 'Cubao',
                      color: Colors.white,
                    ),
                  ),
                  background: Container(
                    color: const Color(0xFF035594),
                  ),
                ),
                actions: [
                  IconButton(
                    icon: const Icon(Icons.account_circle),
                    color: Colors.white,
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const ProfilePage()),
                      );
                    },
                  ),
                ],
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Search...',
                      prefixIcon: const Icon(Icons.search),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide.none,
                      ),
                      filled: true,
                      fillColor: Colors.black12,
                    ),
                  ),
                ),
              ),
              SliverFillRemaining(
                child: _pages[_selectedIndex],
              ),
            ],
          ),
        ),
      ),
      drawer: Drawer(
        child: Stack(
          children: [
            Positioned.fill(
              child: Align(
                alignment: Alignment.topCenter,
                child: Container(
                  height: 190,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('assets/mahal.jpg'),
                      fit: BoxFit.cover,
                      colorFilter: ColorFilter.mode(
                        Colors.black.withOpacity(0.4),
                        BlendMode.darken,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            ListView(
              padding: EdgeInsets.zero,
              children: <Widget>[
                const DrawerHeader(
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                  ),
                  child: Text(
                    'Juan Doe',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                    ),
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.account_circle),
                  title: const Text('Profile'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const ProfilePage()),
                    );
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.map),
                  title: const Text('Maps'),
                  onTap: () {
                    // Navigate to Maps Page
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.question_mark),
                  title: const Text('About'),
                  onTap: () {
                    // Navigate to Community Page
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.call),
                  title: const Text('Contacts'),
                  onTap: () {
                    // Navigate to Hospitals Page
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.directions_bus),
                  title: const Text('Terminals'),
                  onTap: () {
                    // Navigate to Terminals Page
                  },
                ),
              ],
            ),
          ],
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.only(bottom: 20.0),
        child: ClipRRect(
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(30.0),
            topRight: Radius.circular(30.0),
            bottomLeft: Radius.circular(30.0),
            bottomRight: Radius.circular(30.0),
          ),
          child: NavigationBarTheme(
            data: NavigationBarThemeData(
              backgroundColor: const Color(0xFF035594),
              indicatorColor: Colors.green.withOpacity(0.3),
              labelTextStyle: MaterialStateProperty.resolveWith<TextStyle?>(
                    (Set<MaterialState> states) {
                  if (states.contains(MaterialState.selected)) {
                    return const TextStyle(color: Colors.white);
                  }
                  return const TextStyle(color: Colors.white);
                },
              ),
            ),
            child: NavigationBar(
              selectedIndex: _selectedIndex,
              onDestinationSelected: _onItemTapped,
              destinations: <NavigationDestination>[
                NavigationDestination(
                  icon: Image.asset(
                    'assets/logout.png',
                    width: 30,
                    height: 30,
                    color: Colors.white,
                  ),
                  label: 'Logout',
                ),
                NavigationDestination(
                  icon: Image.asset(
                    'assets/lakbay_cavite_logo.png',
                    width: 50,
                    height: 50,
                  ),
                  label: 'Home',
                ),
                NavigationDestination(
                  icon: Image.asset(
                    'assets/setting.png',
                    width: 30,
                    height: 30,
                    color: Colors.white,
                  ),
                  label: 'Settings',
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile Page'),
      ),
      body: const Center(
        child: Text('This is the Profile Page'),
      ),
    );
  }
}
