import 'dart:io';

class Post {
  final String content;
  final File? image;
  final List<String> comments;

  Post({required this.content, this.image, this.comments = const []});
}
