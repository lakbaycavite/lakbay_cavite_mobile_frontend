// event_tracker_page.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'btn_community_event_model.dart';

final List<Event> events = [
  Event(
    name: 'woop event',
    date: DateTime(2024, 9, 15, 9, 0),
    description: 'Join us for a community clean-up drive to make our neighborhood cleaner and greener.',
  ),
  Event(
    name: 'ggggggg',
    date: DateTime(2024, 10, 5, 7, 0),
    description: 'Participate in our charity fun run to support local families in need.',
  ),
  Event(
    name: 'Cultural Festival',
    date: DateTime(2024, 11, 20, 10, 0),
    description: 'Experience the richness of our local culture through music, dance, and food.',
  ),
];

class EventTrackerPage extends StatelessWidget {
  const EventTrackerPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Event Tracker'),
      ),
      body: ListView.builder(
        itemCount: events.length,
        itemBuilder: (context, index) {
          final event = events[index];
          final now = DateTime.now();
          final isOngoing = event.date.isBefore(now) && event.date.add(const Duration(hours: 1)).isAfter(now);
          final isUpcoming = event.date.isAfter(now);

          if (!isOngoing && !isUpcoming) {
            return const SizedBox.shrink(); // Skip events that are not ongoing or upcoming
          }

          return Card(
            margin: const EdgeInsets.all(8.0),
            child: ListTile(
              title: Text(event.name),
              subtitle: Text(DateFormat('MMMM d, yyyy – h:mm a').format(event.date)),
              trailing: isOngoing
                  ? Icon(Icons.event, color: Colors.green)
                  : isUpcoming
                  ? Icon(Icons.schedule, color: Colors.blue)
                  : null,
              onTap: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text(event.name),
                    content: Text(event.description),
                    actions: [
                      TextButton(
                        child: const Text('OK'),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
