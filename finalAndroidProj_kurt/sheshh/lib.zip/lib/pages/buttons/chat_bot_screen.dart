import 'package:flutter/material.dart';

class ChatBotScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CHAT BOT'),
      ),
      body: const Center(
        child: Text('Welcome to the Community Page!'),
      ),
    );
  }
}